package com.wso2.customThreadPool;
import java.io.*;
import java.net.*;

class SimpleClient {

    public static void main(String argv[]) throws Exception {

        String sentence;
        String modifiedSentence;
        Socket clientSocket = new Socket("localhost" , 9000);
        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        sentence = "Client carries the number :" + String.valueOf(Math.random()) ;
        outToServer.writeBytes(sentence + '\n');
        modifiedSentence = inFromServer.readLine();
        System.out.println("FROM SERVER: " + modifiedSentence);
        clientSocket.close();

    }
}